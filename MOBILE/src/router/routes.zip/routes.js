import { eOfficeRoutes } from "components/eof/e-ofice.routes";
const routes = [
  {
    path: "/ver2/comfirm-po",
    component: () => import("layouts/Ver2Layout.vue"),
    children: [
      {
        path: "/",
        component: () => import("pages/production/ver2/ConfirmPo.vue"),
        meta: {
          requiresAuth: true
        }
      }
    ]
  },
  {
    path: "/",
    component: () => import("layouts/MyLayout.vue"),
    children: [
      {
        path: "/",
        component: () => import("pages/production/TyLeDatKH.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/auth",
        component: () => import("pages/Auth.vue")
      },
      // truy cập trái phép
      {
        path: "/access-denied",
        component: () => import("pages/AccessDenied.vue")
      },
      {
        path: "/production-select-feature",
        component: () => import("pages/base/Features.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-select-source",
        component: () => import("pages/production/SelectSource.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-pallet-inline",
        component: () => import("pages/production/PalletInLine.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-comfirm-pallet",
        component: () => import("pages/production/ConfirmPallet.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-create-pallet",
        component: () => import("pages/production/CreatePallet.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-items",
        component: () => import("pages/production/Items.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-xep-say",
        component: () => import("pages/production/XepSay.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-woods-items",
        component: () => import("pages/production/WoodsItems.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-add-supplies/:code",
        name: "addcoc",
        component: () => import("pages/production/AddSupplies.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-all-stock",
        component: () => import("pages/production/AllStock.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-detail-pallet/:code",
        name: "detailpallet",
        component: () => import("pages/production/DetailPallet.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-batchs",
        component: () => import("pages/production/ListBatch.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-detail-batch",
        component: () => import("pages/production/DetailBatch.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-qc-inspection",
        component: () => import("pages/production/QCInspector.vue"),
        meta: {
          requiresAuth: true
        }
      },
      ///production-add-plan-batch
      {
        path: "/production-add-plan-batch",
        component: () => import("pages/production/AddPlanBatch.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-handle-qc",
        component: () => import("pages/production/FormQc.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/test-scan",
        component: () => import("pages/production/ScanPacking.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-packing",
        component: () => import("pages/production/Packing.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-wait-recived",
        component: () => import("pages/production/RecivePallet.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-dashboard",
        component: () => import("pages/production/Dashboard.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-export-finish-good",
        component: () => import("pages/production/ExportFinishGood.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-create-bb-check-mc/:kinlbatchid",
        name: "addbbmc",
        component: () => import("pages/production/CreateBBCheckMc.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-create-bb-kt/:kinlbatchid",
        name: "addbbkt",
        component: () => import("pages/production/QC_Create_BB_KT.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-create-bb-check/:kinlbatchid",
        name: "addbbcheck",
        component: () => import("pages/production/CoDienCreateBBKT.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-qc-history-by-step/:stepid",
        name: "qchistorybystep",
        component: () => import("pages/production/QCViewHistory.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/subs",
        component: () => import("pages/production/ViewBBMC.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-view-bbmc",
        component: () => import("pages/production/ViewBBMC.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-view-bbkt",
        component: () => import("pages/production/ViewBBKT.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-view-bbcodien",
        component: () => import("pages/production/ViewBBCoDien.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-stockout-pallet",
        component: () => import("pages/production/StockOutPallet.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-coc",
        component: () => import("pages/production/DCoCPage.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-add-coc",
        component: () => import("pages/production/AddDCoc.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-edit-coc",
        component: () => import("pages/production/EditDCoc.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/production-workers",
        component: () => import("pages/production/Workers.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/profile",
        component: () => import("pages/base/Profile.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/logout",
        component: () => import("pages/base/Logout.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/ty-le-dat-kh",
        component: () => import("pages/production/TyLeDatKH.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/cap-phoi",
        component: () => import("pages/production/ver2/CapPhoi2.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/chuyen-doi-phoi",
        component: () => import("pages/production/ver2/CatHaCap.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/confirm-po/:code",
        name: "confirm-po",
        component: () => import("pages/production/ConfirmPo.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/receipt-materials",
        component: () => import("pages/production/ver2/Receipt.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/tracking-lot-no",
        component: () => import("pages/production/ver2/MagazineInfo.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/history-confirm",
        component: () => import("pages/production/ver2/HistoryConfirm.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/create-pallet-v2",
        component: () => import("pages/production/CreatePlV2.vue"),
        meta: {
          requiresAuth: true
        }
      },
      //test
      {
        path: "/test",
        component: () => import("pages/production/Packing2.vue"),
        meta: {
          requiresAuth: true
        }
      },
      //phân hệ nội thất
      {
        path: "/funiture-dashboard",
        component: () => import("pages/funiture/Dashboard.vue"),
        meta: {
          requiresFuniture: true
        }
      },
      {
        path: "/funiture-create-pallet",
        component: () => import("pages/funiture/CreatePallet.vue"),
        meta: {
          requiresFuniture: true
        }
      },
      {
        path: "/funiture-select-project",
        component: () => import("pages/funiture/SelectProject.vue"),
        meta: {
          requiresFuniture: true
        }
      },
      {
        path: "/funiture-stockout-pallet",
        component: () => import("pages/funiture/StockOutPallet.vue"),
        meta: {
          requiresFuniture: true
        }
      },
      {
        path: "/funiture-accepts",
        component: () => import("pages/funiture/AcceptsList.vue"),
        meta: {
          requiresFuniture: true
        }
      },
      {
        path: "/funiture-detail-accept/:id",
        name: "detail-accept",
        component: () => import("pages/funiture/DetailAccept.vue"),
        meta: {
          requiresFuniture: true
        }
      },
      {
        path: "/funiture-packing",
        component: () => import("pages/funiture/Packing.vue"),
        meta: {
          requiresFuniture: true
        }
      },
      {
        path: "/funiture-create-good-issue",
        component: () => import("pages/funiture/CreateGoodIssue.vue"),
        meta: {
          requiresFuniture: true
        }
      },
      {
        path: "/funiture-detail-good-issue/:id",
        name: "detail-good-issue",
        component: () => import("pages/funiture/DetailGoodIssue.vue"),
        meta: {
          requiresFuniture: true
        }
      },

      // phân hệ ván, và nguyên liệu gỗ
      {
        path: "/wood-list-receipt",
        component: () => import("pages/wood/ListReceipt.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-add-receipt",
        component: () => import("pages/wood/AddReceipt.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-list-pay",
        component: () => import("pages/wood/ListPayment.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-warehouse/:id",
        name: "wood-detail",
        component: () => import("pages/wood/ViewWHDetail.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/add-wood-warehouse-dlt/:id",
        name: "add-wh-detail",
        component: () => import("pages/wood/FormAddWHDetail.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/edit-wood-warehouse-dlt/:id",
        name: "edit-wh-detail",
        component: () => import("pages/wood/EditReceiptDetail.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-inspection/:id",
        name: "wood-inspection",
        component: () => import("pages/wood/InspectionDetail.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/add-wood-inspection/:id",
        name: "add-inspection",
        component: () => import("pages/wood/AddInspection.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/edit-wood-inspection/:id",
        name: "edit-inspection",
        component: () => import("pages/wood/EditInspection.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-view-inspection/:id",
        name: "view-inspection",
        component: () => import("pages/wood/ViewInspection.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-view-payment/:id",
        name: "view-payment",
        component: () => import("pages/wood/ViewPay.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-view-payment-completed/:id",
        name: "view-payment-completed",
        component: () => import("pages/wood/PrintPayInfo.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-pay-manual/:id",
        name: "pay-manual",
        component: () => import("pages/wood/PayManual.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-price-list",
        component: () => import("pages/wood/PriceList.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-price-update",
        component: () => import("pages/wood/PriceUpdate.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-price-approval",
        component: () => import("pages/wood/PriceApproval.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-view-req-price/:id",
        name: "view-req-price",
        component: () => import("pages/wood/ViewReqPrice.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-setting-home",
        component: () => import("pages/wood/setting/Index.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-setting-supplier",
        component: () => import("pages/wood/setting/Supplier.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-setting-item",
        component: () => import("pages/wood/setting/QuiCach.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-create-pallet",
        component: () => import("pages/wood/CreatePallet.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-create-pallet2",
        component: () => import("pages/wood/CreatePalletSay.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/van-xuat-kho-sau-say",
        component: () => import("pages/wood/XuatKhoSauSay.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-out-stock-location",
        component: () => import("pages/wood/OutStockLocation.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-reports",
        component: () => import("pages/wood/reports/Index.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/van-ghi-nhan-hoan-thien",
        component: () => import("pages/wood/GhiNhanHoanThien.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/xuat-so-lo",
        component: () => import("pages/wood/XuatLo.vue"),
        meta: {
          requiresAuth: true
        }
      },

      {
        path: "/wood-warehouse-receipts",
        component: () => import("pages/wood/NLG/PhieuNhapKho.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-warehouse-receipts-dlt",
        component: () => import("pages/wood/NLG/CT_PhieuNhapKho.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/wood-add-wh-receipts-dlt",
        component: () => import("pages/wood/NLG/NhapKho.vue"),
        meta: {
          requiresAuth: true
        }
      },

      {
        path: "/nhap-ton-dau-ky",
        component: () => import("pages/production/ver2/NhapTonDauKy.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/tao-phoi",
        component: () => import("pages/TaoPhoi.vue"),
        meta: {
          requiresAuth: true
        }
      },
      {
        path: "/duyet-phoi",
        component: () => import("pages/DuyetPhoi.vue"),
        meta: {
          requiresAuth: true
        }
      },
      ...eOfficeRoutes
    ]
  }
];

// Always leave this production-kho-lua-phoi as last one /production-detail-batch production-add-supplies /production-xep-say /production-items /production-pallet-inline /production-comfirm-pallet
if (process.env.MODE !== "ssr") {
  routes.push({
    path: "*",
    name: "notFound",
    component: () => import("pages/Error404.vue")
  });
}

export default routes;
