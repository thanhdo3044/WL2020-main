<template>
  <q-page class="q-pa-sm">
    <q-card class="my-card">
      <q-card-section>
        <div class="row">
          <div class="col-6 top-title">Báo cáo sản lượng công đoạn sản xuất</div>
          <div
            class="col-6 top-title cursor-pointer"
            align="right"
            @click="showChooseDate = true"
          >Từ ngày {{ tuNgay }} đến {{ denNgay }}</div>
        </div>
      </q-card-section>
      <q-separator inset />
      <q-card-section>
        <div class="row q-mt-md">
          <div class="col-12">
            <DxDataGrid
              :data-source="packages"
              :show-borders="true"
              :no-data-text="'Nhấn xem báo cáo để lấy dữ liệu'"
              :show-column-lines="true"
              :allow-column-resizing="true"
            >
              <DxColumnChooser :enabled="true" />
              <DxHeaderFilter :visible="true" />
              <DxGroupPanel
                :visible="true"
                :empty-panel-text="
                  'Kéo một tiêu đề cột vào đây để nhóm theo cột đó'
                "
              />
              <DxGrouping :auto-expand-all="true" />
              <DxColumn
                data-field="name"
                caption="Công đoạn"
                :group-index="0"
                :sort-index="0"
                sort-order="desc"
              />
              <DxColumn data-field="tenSP" caption="Tên SP" />
              <!-- <DxColumn data-field="name" caption="Công đoạn" /> -->
              <DxColumn caption="Tồn đầu kỳ" alignment="center">
                <DxColumn data-field="tonDauKy" caption="Số lượng" />
                <DxColumn data-field="khoiLuongTonDauKy" caption="Khối lượng" />
              </DxColumn>
              <DxColumn caption="Nhập" alignment="center">
                <DxColumn data-field="QUANTITY" caption="Số lượng" />
                <DxColumn data-field="khoiLuongNhan" caption="Khối lượng" />
              </DxColumn>
              <DxColumn caption="Xuất" alignment="center">
                <DxColumn data-field="soLuongXuat" caption="Số lượng" />
                <DxColumn data-field="khoiLuongXuat" caption="Khối lượng" />
              </DxColumn>

              <DxColumn caption="Tồn cuối kỳ" alignment="center">
                <DxColumn data-field="tonCuoiKy" caption="Số lượng" />
                <DxColumn data-field="khoiLuongTonCuoiKy" caption="Khối lượng" />
              </DxColumn>
              <DxSummary>
                <DxGroupItem
                  column="QUANTITY"
                  summary-type="sum"
                  data-type="number"
                  :show-in-group-footer="false"
                  :align-by-column="true"
                  :display-format="'{0}'"
                  :value-format="'fixedpoint'"
                />
              </DxSummary>
              <DxExport
                :enabled="true"
                :allow-export-selected-data="false"
                :file-name="
                  'Dữ liệu sản xuất chi tiết từ ngày ' +
                    tuNgay +
                    ' đến ngày ' +
                    denNgay
                "
              />
              <DxSearchPanel :visible="true" :placeholder="'Tìm kiếm'" :width="400" />
            </DxDataGrid>
          </div>
        </div>
      </q-card-section>
    </q-card>
    <DialogSelectDate
      :selectDate="chooseDate"
      :showChooseDate="showChooseDate"
      :cancelChooseDate="cancelChooseDate"
    />
  </q-page>
</template>

<script>
import {
  DxDataGrid,
  DxColumn,
  DxGrouping,
  DxGroupPanel,
  DxPager,
  DxPaging,
  DxSearchPanel,
  DxExport,
  DxSummary,
  DxGroupItem,
  DxHeaderFilter,
  DxColumnChooser,
  DxMasterDetail,
  DxTotalItem
} from "devextreme-vue/data-grid";
import DialogSelectDate from "../../../components/commons/DialogSelectFromDateToDate";
import {
  formatDateISO,
  getFisrtDayOfMonth,
  formatDateVN
} from "../../../ultils";
import { mapGetters, mapActions } from "vuex";
import moment from "moment";
export default {
  data() {
    return {
      showChooseDate: false,
      fromDate: moment().subtract(30, "days"),
      toDate: moment()
    };
  },
  computed: {
    ...mapGetters("itemInPackages", ["packages"]),
    tuNgay() {
      return formatDateVN(this.fromDate);
    },
    denNgay() {
      return formatDateVN(this.toDate);
    }
  },
  created() {
    this.load();
  },
  methods: {
    ...mapActions("itemInPackages", ["getAllPackage"]),

    async load() {
      let payload = {
        fromDate: moment(this.fromDate)
          .startOf("days")
          .format(),
        toDate: moment(this.toDate)
          .endOf("days")
          .format()
      };
      console.log(payload);
      this.getAllPackage(payload);
    },

    cancelChooseDate() {
      this.showChooseDate = false;
    },

    async chooseDate(f, t) {
      this.fromDate = f;
      this.toDate = t;
      this.showChooseDate = false;
      this.load();
    }
  },
  components: {
    DxDataGrid,
    DxColumn,
    DxGrouping,
    DxGroupPanel,
    DxPager,
    DxPaging,
    DxSearchPanel,
    DxExport,
    DialogSelectDate,
    DxSummary,
    DxGroupItem,
    DxHeaderFilter,
    DxColumnChooser,
    DxMasterDetail,
    DxTotalItem
  }
};
</script>

<style></style>
