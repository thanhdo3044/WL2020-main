﻿<template>
  <DxDataGrid
    id="gridContainer"
    :data-source="users"
    :allow-column-reordering="true"
    :columns-auto-width="true"
    :show-borders="true"
    :selection="{ mode: 'single' }"
    :hover-state-enabled="true"
    @selection-changed="onSelectionChanged"
    @editorPreparing="onEditorPreparing"
    @row-inserted="insert"
    @row-updated="updated"
    key-expr="id"
  >
    <DxPaging :enabled="true" :page-size="40" />
    <DxEditing :allow-updating="true" :allow-adding="true" mode="popup" />
    <DxFilterRow :visible="true" />

    <DxSearchPanel :visible="true" :width="100" placeholder="Tìm tài khoản" />
    <DxColumn data-field="account" caption="Tên đăng nhập" :width="80">
      <DxRequiredRule />
    </DxColumn>
    <DxColumn data-field="lastName" caption="Họ Tên">
      <DxRequiredRule />
    </DxColumn>
    <DxColumn data-field="position" caption="Chức vụ" :visible="false">
      <DxRequiredRule />
    </DxColumn>
    <DxColumn data-field="departmentId" caption="Phòng ban" :visible="false">
      <DxLookup :data-source="departments" display-expr="name" value-expr="id" />
      <DxRequiredRule />
    </DxColumn>
    <DxColumn data-field="factoryId" caption="Nhà máy" :visible="false">
      <DxLookup :data-source="departmentsFilter" display-expr="name" value-expr="id" />
      <DxRequiredRule />
    </DxColumn>
  </DxDataGrid>
</template>

<script>
import { mapGetters } from "vuex";
import {
  DxDataGrid,
  DxColumn,
  DxEditing,
  DxPaging,
  DxRequiredRule,
  DxLookup,
  DxSearchPanel,
  DxHeaderFilter,
  DxFilterRow,
} from "devextreme-vue/data-grid";
import { showNotifySuccess, showNotifyError } from "../../ultils";
export default {
  components: {
    DxDataGrid,
    DxColumn,
    DxEditing,
    DxPaging,
    DxLookup,
    DxSearchPanel,
    DxHeaderFilter,
    DxFilterRow,
    DxRequiredRule,
  },
  props: {
    onSelectionChanged: {
      type: Function,
    },
  },
  data() {
    return {
      users: [],
      departments: [],
      departmentsFilter: [],
      roles: [],
    };
  },
  created() {
    Promise.all([this.loadUser(), this.loadRoles(), this.loadDepartment()]);
  },
  computed: {
    ...mapGetters("base", ["myFactoryInfor"]),
  },
  methods: {
    async insert(e) {
      let payload = {
        account: e.data.account,
        lastName: e.data.lastName,
        roleId: e.data.roleId,
        departmentId: e.data.departmentId,
        factoryId: e.data.factoryId,
        position: e.data.position,
        password: "01",
      };
      const data = await this.$store.dispatch("base/CREATE_ACCOUNT", payload);
      if (data.meta.success) {
        await this.loadUser();
        showNotifySuccess("Tạo tài khoản thành công !");
      } else {
        showNotifyError();
      }
    },
    async updated(e) {
      // console.log(e.data)

      if (e.data) {
        console.log(e.data);
        const payload = {
          id: e.data.id,
          data: {
            ...e.data,
          },
        };
        const data = await this.$store.dispatch("base/UPDATE_ACCOUNT", payload);
        if (data.meta.success) {
          showNotifySuccess("Cập nhật thành công !");
        } else {
          showNotifyError();
        }
      }
    },
    async loadUser() {
      const data = await this.$store.dispatch("base/GET_ACCOUNTS");
      this.users = data.data;
    },
    async loadRoles() {
      // const data = await this.$store.dispatch('base/GET_ROLES')
      // this.roles = data.data
      return true;
    },
    async loadDepartment() {
      let dataProfile = await this.$store.dispatch("base/GET_ACCOUNTS");
      console.log(dataProfile);
      const data = await this.$store.dispatch("base/GET_DEPARTMENTS", {
        factoryId: this.myFactoryInfor.id,
      });
      this.departments = data.data;
      this.departmentsFilter = data.data.filter(
        (item) => item.type2 == "factory"
      );
    },
    // async onSelectionChanged({ selectedRowsData }){
    //     const data = selectedRowsData[0];
    //     let dataRole = await this.$store.dispatch('base/GET_ROLE_INFO_BY_ID',data.roleId)
    //     // console.log(dataRole.data)
    //     this.$q.loading.show(

    //     )
    //     setTimeout(() => {
    //         this.$root.$emit('chon_role', dataRole.data)
    //         this.$q.loading.hide()
    //     }, 1500);

    // },
    onEditorPreparing(e) {
      if (e.dataField === "id" || e.dataField === "roleId") {
        e.editorOptions.disabled = true;
      }
    },
  },
};
</script>

<style></style>
